/**
 *  @Author: 
 *	@Date: 23/12/2017
 *	@Summary: This code is designed to realize a real time clock with 32762Hz 
 *						quart through interruption method.
 */

#define __18CXX          //means "any pic18"
#include <pic18fregs.h>  //defines the address corresponding to the symbolic
                         //names of the sfr

#include "Include/TCPIP_Stack/Delay.h"
#include "Include/HardwareProfile.h"
#include "Include/TCPIP_Stack/TCPIP.h" //ML
#include "Include/LCDBlocking.h"

#include "TCPIP_Stack/LCDBlocking.c"

#include <string.h>
#include <stdlib.h>

void DisplayString(BYTE pos, char* text);
void low_isr(void);
void high_isr(void);

#define CLOCK_FREQ 40000000 // 40 Mhz
#define EXEC_FREQ CLOCK_FREQ/4 // 4 clock cycles to execute an instruction

#define LOW(a)     (a & 0xFF)
#define HIGH(a)    ((a>>8) & 0xFF)

#define SM 60
#define H 24

#define CLOCK 0
#define SET_CLOCK 1
#define SET_ALARM 2


#define B1 PORTBbits.RB3
#define B2 PORTBbits.RB1

#define LED1 LATJbits.LATJ0
#define LED2 LATJbits.LATJ1

/* Variable */
BYTE LCDText[16*2+1];

volatile unsigned char update = 0;
volatile unsigned int led_clk = 0, n_blink = 0;
volatile unsigned int step = 0;
volatile unsigned char buf[17];

volatile unsigned int hour = 0;
volatile unsigned int minute = 0;
volatile unsigned int second = 0;

volatile unsigned int a_hour = 0;
volatile unsigned int a_minute = 0;
volatile unsigned int a_second = 0;

// wait for approx 1ms
void delay_1ms(void) {
	volatile unsigned int i = 0;
	for(i = 0; i < 10000; i++);
}
 
// wait for some ms
void delay_ms(unsigned int ms) {
	while (ms--) {
		delay_1ms();
	}
}

void initTMR0(){
	T0CON = 0X07;
	TMR0L = LOW(39063);
	TMR0H = HIGH(39063);
	// Enable Interrupt
	INTCONbits.TMR0IE = 1;
	INTCONbits.TMR0IF = 0;
	T0CONbits.TMR0ON = 1;
	INTCON2bits.TMR0IP = 1;
	RCONbits.IPEN = 1;
	INTCONbits.GIE = 1;
}

// initialize board
void init_board(void) {
	TRISJbits.TRISJ0=0; // configure PORTJ0 for output (LED)
	TRISJbits.TRISJ1=0; // configure PORTJ1 for output (LED)

	TRISBbits.TRISB3 = 1;
	TRISBbits.TRISB1 = 1;
	
	// Enable interrupt
	INTCON3bits.INT1IF = 0;
	INTCON3bits.INT3IF = 0;
	INTCON2bits.INTEDG1 = 0;
	INTCON2bits.INTEDG3 = 0;
	INTCON2bits.INT3IP = 0;
	INTCON3bits.INT1IP = 0;
	
	INTCON3bits.INT1IE = 1;
	INTCON3bits.INT3IE = 1;
	
	// TMR0
	initTMR0();
}

void main() {
	init_board();
	LED1 = 1;
	LED2 = 1;
	LCDInit();

	while(1) {

		/* LCD DISPLAY */
		if(update  || (step == SET_CLOCK) || (step == SET_ALARM)){
			switch(step){
				case CLOCK:{
					DisplayString(0, "Clock           ");
					sprintf(buf,"    %d%d:%d%d:%d%d    \0",(int)(hour/10),(int)(hour%10),(int)(minute/10),(int)(minute%10),(int)(second/10),(int)(second%10));
					DisplayString(16, buf);
					update = 0;
					break;
				}
				case SET_CLOCK:{
					DisplayString(0, "Set clock       ");
					sprintf(buf,"    %d%d:%d%d:%d%d    \0",(int)(hour/10),(int)(hour%10),(int)(minute/10),(int)(minute%10),(int)(second/10),(int)(second%10));
					DisplayString(16, buf);
					break;
				}
				case SET_ALARM:{
					DisplayString(0, "Set alarm       ");
					sprintf(buf,"    %d%d:%d%d:%d%d    \0",(int)(a_hour/10),(int)(a_hour%10),(int)(a_minute/10),(int)(a_minute%10),(int)(a_second/10),(int)(a_second%10));
					DisplayString(16, buf);
					break;
				}
			}
		}

		/* Alarm matching */
		if((hour == a_hour) && (minute == a_minute)){
			if((led_clk >= 1000)&&(n_blink <= 30)){
				LED1 ^= 1;
				//LED2 ^= 1;
				led_clk = 0;
				n_blink++;
			}else { LED1 = 0; }
		}else if(n_blink != 0) { n_blink = 0; }

		/* 1ms delay */
		delay_1ms();
		if((hour == a_hour) && (minute == a_minute)) led_clk++;
	}
}

/*************************************************
 Function DisplayString: 
 Writes the first characters of the string in the remaining 
 space of the 32 positions LCD, starting at pos
 (does not use strlcopy, so can use up to the 32th place)
*************************************************/
void DisplayString(BYTE pos, char* text)
{
   BYTE        l = strlen(text);/*number of actual chars in the string*/
   BYTE      max = 32-pos;    /*available space on the lcd*/
   char       *d = (char*)&LCDText[pos];
   const char *s = text;
   size_t      n = (l<max)?l:max;
   /* Copy as many bytes as will fit */
    if (n != 0)
      while (n-- != 0)*d++ = *s++;
   LCDUpdate();

}

#pragma code high_vector=0x08
void interrupt_at_high_vector(void)
{
    _asm goto high_isr _endasm
}
#pragma code

#pragma code low_vector=0x18
void interrupt_at_low_vector(void)
{
    _asm goto low_isr _endasm
}
#pragma code

/******************************************************************************
 * Function:        void high_isr(void)
 * PreCondition:    None
 * Input:
 * Output:
 * Side Effects:
 * Overview:
 *****************************************************************************/
#pragma interrupt high_isr
void high_isr(void)
{
	if(INTCONbits.TMR0IF){
		INTCONbits.GIE = 0;
		INTCONbits.TMR0IF = 0;
		second++;
		if(second == SM) { second = 0; minute++; }
		if(minute == SM) { minute = 0; hour++; }
		if(hour == H) { hour = 0; }
		update = 1;
		INTCONbits.GIE = 1;
	}
}

/******************************************************************************
 * Function:        void low_isr(void)
 * PreCondition:    None
 * Input:
 * Output:
 * Side Effects:
 * Overview:
 *****************************************************************************/
#pragma interruptlow low_isr
void low_isr(void)
{
	if(INTCON3bits.INT3IF){
		INTCONbits.GIE = 0;
		INTCON3bits.INT3IF = 0;
		step++;
		if(step>=3) step = 0;	
		delay(50); // 50ms
		INTCONbits.GIE = 1;		
	}else if(INTCON3bits.INT1IF){
		INTCONbits.GIE = 0;
		INTCON3bits.INT1IF = 0;
		if(step == SET_ALARM){
			a_second++;
			if(a_second == SM) { a_second = 0; a_minute++; }
			if(a_minute == SM) { a_minute = 0; a_hour++; }
			if(a_hour == H) { a_hour = 0; }
		}
		
		if(step == SET_CLOCK){
			second++;
			if(second == SM) { second = 0; minute++; }
			if(minute == SM) { minute = 0; hour++; }
			if(hour == H) { hour = 0; }
		}
		
		delay(50); // 50ms
		INTCONbits.GIE = 1;
	}
}
#pragma code
